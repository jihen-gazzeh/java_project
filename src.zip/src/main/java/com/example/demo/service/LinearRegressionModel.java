package com.example.demo.service;

import org.apache.commons.math3.stat.regression.SimpleRegression;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class LinearRegressionModel extends PredictionModel {

    @Override
    public List<Map<String, Object>> trainAndPredict(List<Double> prices, List<String> dates) throws Exception {
        // Date format for parsing and formatting
        SimpleDateFormat inputDateFormat = new SimpleDateFormat("MM/dd/yyyy");
        SimpleDateFormat outputDateFormat = new SimpleDateFormat("MM/dd/yyyy");

        // List to store numerical date values (milliseconds) and date-price pairs
        List<Long> numericalDates = new ArrayList<>();
        List<Map.Entry<Long, Double>> datePricePairs = new ArrayList<>();

        // Convert dates to milliseconds and store them along with corresponding prices
        for (int i = 0; i < dates.size(); i++) {
            try {
                long parsedDate = inputDateFormat.parse(dates.get(i)).getTime();
                numericalDates.add(parsedDate);
                datePricePairs.add(new AbstractMap.SimpleEntry<>(parsedDate, prices.get(i)));
            } catch (ParseException e) {
                System.err.println("Error parsing date: " + dates.get(i));
            }
        }

        // Sort the date-price pairs by date
        datePricePairs.sort(Comparator.comparing(Map.Entry::getKey));
        numericalDates.sort(Comparator.naturalOrder());

        // Create a list of sorted prices to match the sorted dates
        List<Double> sortedPrices = new ArrayList<>();
        for (Map.Entry<Long, Double> entry : datePricePairs) {
            sortedPrices.add(entry.getValue());
        }

        // Create the linear regression model
        SimpleRegression regression = new SimpleRegression();

        // Add data to the regression model
        for (int i = 0; i < numericalDates.size(); i++) {
            regression.addData(numericalDates.get(i), sortedPrices.get(i));
        }

        // List to store the predictions
        List<Map<String, Object>> predictions = new ArrayList<>();

        // Time difference for one day in milliseconds
        long oneDayMillis = 24 * 60 * 60 * 1000L;
        long lastDate = numericalDates.get(numericalDates.size() - 1);

        // Make predictions for the next 5 days
        for (int i = 1; i <= 5; i++) {
            long nextDate = lastDate + (i * oneDayMillis);
            double predictedPrice = regression.predict(nextDate);

            // Create a map with the prediction date and predicted price
            Map<String, Object> prediction = new HashMap<>();
            prediction.put("date", outputDateFormat.format(new Date(nextDate)));
            prediction.put("predictedPrice", predictedPrice);
            predictions.add(prediction);
        }

        // Return the list of predictions
        return predictions;
    }
}
