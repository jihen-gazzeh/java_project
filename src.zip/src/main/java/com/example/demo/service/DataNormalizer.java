package com.example.demo.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

class DataNormalizer extends DataProcessor {
    @Override
    public List<Double> process(List<Double> data) {
        if (data.isEmpty()) return data;
        double min = Collections.min(data);
        double max = Collections.max(data);
        List<Double> normalizedData = new ArrayList<>();
        for (Double value : data) {
            normalizedData.add((value - min) / (max - min));
        }
        return normalizedData;
    }
}