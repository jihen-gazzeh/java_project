package com.example.demo.service;

import java.util.List;

abstract class DataProcessor {
    public abstract List<Double> process(List<Double> data);
}
