package com.example.demo.service;

import java.util.List;
import java.util.Map;

public abstract class PredictionModel {
    // Abstract method that must be implemented by subclasses
    public abstract List<Map<String, Object>> trainAndPredict(List<Double> prices, List<String> dates) throws Exception;
}
