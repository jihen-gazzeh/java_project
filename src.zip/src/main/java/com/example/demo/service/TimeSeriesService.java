package com.example.demo.service;

import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class TimeSeriesService {

    // Method for extracting price data from parsed CSV/XLSX file
    public List<Double> getPriceData(List<List<String>> filePreview) {
        List<Double> priceData = new ArrayList<>();
        int priceColumnIndex = 1;  // Assuming price is in the second column (index 1)

        for (int row = 1; row < filePreview.size(); row++) {
            try {
                priceData.add(Double.parseDouble(filePreview.get(row).get(priceColumnIndex)));
            } catch (NumberFormatException e) {
                // Skip non-numeric values in the price column
            }
        }
        return priceData;
    }

    // Time series analysis - extracting dates and prices
    public Map<String, List<?>> timeSeriesAnalysis(List<List<String>> filePreview) {
        List<String> dates = new ArrayList<>();
        List<Double> prices = new ArrayList<>();

        for (int i = 1; i < filePreview.size(); i++) {
            try {
                String date = filePreview.get(i).get(0); // Assuming dates are in the first column
                Double price = Double.parseDouble(filePreview.get(i).get(1)); // Assuming prices are in the second column
                dates.add(date);
                prices.add(price);
            } catch (NumberFormatException e) {
                // Skip invalid data
            }
        }

        Map<String, List<?>> result = new HashMap<>();
        result.put("dates", dates);
        result.put("prices", prices);
        return result;
    }
    public List<Double> getOtherData(List<List<String>> filePreview) {
        List<Double> otherData = new ArrayList<>();
        for (int i = 1; i < filePreview.size(); i++) {
            try {
                otherData.add(Double.parseDouble(filePreview.get(i).get(2))); // Assuming 3rd column is other data
            } catch (NumberFormatException e) {
                // Handle invalid data
            }
        }
        return otherData;
    }

}
