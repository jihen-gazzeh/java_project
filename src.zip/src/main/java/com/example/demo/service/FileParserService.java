package com.example.demo.service;

import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

@Service
public class FileParserService {

    public List<List<String>> parseFile(MultipartFile file) throws IOException {
        String fileExtension = getFileExtension(file.getOriginalFilename());
        if (fileExtension.equalsIgnoreCase("xlsx")) {
            return parseXlsxFile(file);
        } else if (fileExtension.equalsIgnoreCase("csv")) {
            return parseCsvFile(file);
        }
        throw new IOException("Unsupported file format.");
    }

    private List<List<String>> parseXlsxFile(MultipartFile file) throws IOException {
        List<List<String>> data = new ArrayList<>();
        try (InputStream is = file.getInputStream()) {
            Workbook workbook = new XSSFWorkbook(is);
            Sheet sheet = workbook.getSheetAt(0);
            Iterator<Row> rowIterator = sheet.iterator();

            while (rowIterator.hasNext()) {
                Row row = rowIterator.next();
                List<String> rowData = new ArrayList<>();
                for (Cell cell : row) {
                    rowData.add(cell.toString());
                }
                data.add(rowData);
            }
        }
        return data;
    }

    private List<List<String>> parseCsvFile(MultipartFile file) throws IOException {
        List<List<String>> data = new ArrayList<>();
        try (Reader reader = new InputStreamReader(file.getInputStream());
             CSVReader csvReader = new CSVReader(reader)) {

            String[] row;
            while ((row = csvReader.readNext()) != null) {
                data.add(Arrays.asList(row));
            }
        } catch (CsvValidationException e) {
            throw new RuntimeException(e);
        }
        return data;
    }

    private String getFileExtension(String fileName) {
        int index = fileName.lastIndexOf('.');
        return (index > 0) ? fileName.substring(index + 1) : "";
    }
}
