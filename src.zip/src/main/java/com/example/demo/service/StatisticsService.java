package com.example.demo.service;

import org.apache.commons.math3.stat.correlation.PearsonsCorrelation;
import org.apache.commons.math3.stat.descriptive.DescriptiveStatistics;
import org.apache.commons.math3.stat.regression.SimpleRegression;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class StatisticsService {

    public Map<String, Object> calculateDescriptiveStats(List<List<String>> filePreview) {
        Map<String, Object> stats = new HashMap<>();
        int priceColumnIndex = 1;
        List<Double> priceData = new ArrayList<>();

        for (int row = 1; row < filePreview.size(); row++) {
            try {
                priceData.add(Double.parseDouble(filePreview.get(row).get(priceColumnIndex)));
            } catch (NumberFormatException e) {
                // Skip non-numeric cells
            }
        }

        if (!priceData.isEmpty()) {
            DescriptiveStatistics priceStats = new DescriptiveStatistics();
            priceData.forEach(priceStats::addValue);

            double mean = priceStats.getMean();
            double median = priceStats.getPercentile(50);
            double stdDev = priceStats.getStandardDeviation();
            double mode = getMode(priceData);

            stats.put("Mean Price", mean);
            stats.put("Median Price", median);
            stats.put("Standard Deviation Price", stdDev);
            stats.put("Mode Price", mode);
        }

        return stats;
    }

    private double getMode(List<Double> data) {
        // Step 1: Create a frequency map using groupingBy() and counting()
        Map<Double, Long> frequencyMap = data.stream()
                .collect(Collectors.groupingBy(e -> e, Collectors.counting()));

        // Step 2: Find the entry with the highest frequency (max count)
        return frequencyMap.entrySet().stream()
                .max(Map.Entry.comparingByValue())  // Compare based on value (frequency)
                .map(Map.Entry::getKey)             // Get the key (the mode)
                .orElse(Double.NaN);                // If no mode, return NaN
    }


    public double calculateCorrelation(List<Double> xData, List<Double> yData) {
        PearsonsCorrelation correlation = new PearsonsCorrelation();
        double[] x = xData.stream().mapToDouble(Double::doubleValue).toArray();
        double[] y = yData.stream().mapToDouble(Double::doubleValue).toArray();
        return correlation.correlation(x, y);
    }

    public Map<String, Double> performRegression(List<Double> xData, List<Double> yData) {
        SimpleRegression regression = new SimpleRegression();
        for (int i = 0; i < xData.size(); i++) {
            regression.addData(xData.get(i), yData.get(i));
        }
        Map<String, Double> regressionStats = new HashMap<>();
        regressionStats.put("Slope", regression.getSlope());
        regressionStats.put("Intercept", regression.getIntercept());
        regressionStats.put("R-Squared", regression.getRSquare());
        return regressionStats;
    }

    public Map<String, List<?>> calculateTrendSeasonalityResiduals(List<List<String>> filePreview) {
        List<String> dates = new ArrayList<>();
        List<Double> prices = new ArrayList<>();
        List<Double> trend = new ArrayList<>();
        List<Double> seasonal = new ArrayList<>();
        List<Double> residuals = new ArrayList<>();

        for (int i = 1; i < filePreview.size(); i++) {
            try {
                String dateStr = filePreview.get(i).get(0);
                Double price = Double.parseDouble(filePreview.get(i).get(1));

                dates.add(dateStr);
                prices.add(price);
            } catch (NumberFormatException e) {
                // Handle invalid data in the columns
            }
        }

        int windowSize = 5;
        for (int i = 0; i < prices.size(); i++) {
            double trendValue = 0.0;
            int count = 0;

            for (int j = Math.max(0, i - windowSize); j < Math.min(prices.size(), i + windowSize + 1); j++) {
                trendValue += prices.get(j);
                count++;
            }
            trendValue /= count;

            double seasonalValue = prices.get(i) - trendValue;
            double residualValue = prices.get(i) - trendValue - seasonalValue;

            trend.add(trendValue);
            seasonal.add(seasonalValue);
            residuals.add(residualValue);
        }

        Map<String, List<?>> trendSeasonalityResiduals = new HashMap<>();
        trendSeasonalityResiduals.put("trend", trend);
        trendSeasonalityResiduals.put("seasonal", seasonal);
        trendSeasonalityResiduals.put("residuals", residuals);

        return trendSeasonalityResiduals;
    }
}
