package com.example.demo.service;
import org.apache.commons.math3.stat.regression.SimpleRegression;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.List;
import java.util.stream.Collectors;
import java.util.Collections;

@Service
public class DataAnalysisService {
    private static final String UPLOAD_DIR = "uploads/";
    private final DataProcessor outlierRemover = new OutlierRemover();
    private final DataProcessor normalizer = new DataNormalizer();
    private final PredictionModel regressionModel = new LinearRegressionModel();

    public void saveFile(MultipartFile file) throws IOException {
        Path path = Paths.get(UPLOAD_DIR + file.getOriginalFilename());
        Files.createDirectories(path.getParent());
        Files.write(path, file.getBytes());
    }

    public List<List<String>> removeRowsWithMissingValues(List<List<String>> data) {
        return data.stream()
                .filter(row -> row.stream().noneMatch(value -> value == null || value.isEmpty()))
                .collect(Collectors.toList());
    }

    public List<Double> removeOutliers(List<Double> data) {
        return outlierRemover.process(data);
    }

    public List<Double> normalizeData(List<Double> data) {
        return normalizer.process(data);
    }

    public List<Map<String, Object>> trainAndPredict(List<Double> prices, List<String> dates) throws Exception {
        return regressionModel.trainAndPredict(prices, dates);
    }
}