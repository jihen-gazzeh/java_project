package com.example.demo.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

class OutlierRemover extends DataProcessor {
    @Override
    public List<Double> process(List<Double> data) {
        if (data.isEmpty()) return data;

        Collections.sort(data);
        int n = data.size();
        double Q1 = data.get(n / 4);
        double Q3 = data.get(3 * n / 4);
        double IQR = Q3 - Q1;
        double lowerBound = Q1 - 1.5 * IQR;
        double upperBound = Q3 + 1.5 * IQR;

        List<Double> cleanedData = new ArrayList<>();
        for (Double value : data) {
            if (value >= lowerBound && value <= upperBound) {
                cleanedData.add(value);
            }
        }
        return cleanedData;
    }
}
