package com.example.demo.controller;

import com.example.demo.model.FileMetadata;
import com.example.demo.repository.FileMetadataRepository;
import com.example.demo.service.DataAnalysisService;
import com.example.demo.service.FileParserService;
import com.example.demo.service.StatisticsService;
import com.example.demo.service.TimeSeriesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

@Controller
public class FileUploadController {

    private static final String UPLOAD_DIR = "uploads/";

    @Autowired
    private FileMetadataRepository fileMetadataRepository;

    @Autowired
    private DataAnalysisService dataAnalysisService;

    @Autowired
    private FileParserService fileParserService;

    @Autowired
    private StatisticsService statisticsService;

    @Autowired
    private TimeSeriesService timeSeriesService;

    @PostMapping("/upload")
    public String handleFileUpload(@RequestParam("file") MultipartFile file, RedirectAttributes redirectAttributes) {
        if (file.isEmpty()) {
            redirectAttributes.addFlashAttribute("message", "Please select a file to upload.");
            return "redirect:/index";
        }

        String fileExtension = getFileExtension(file.getOriginalFilename());
        if (!fileExtension.equalsIgnoreCase("csv") && !fileExtension.equalsIgnoreCase("xlsx")) {
            redirectAttributes.addFlashAttribute("message", "Only .csv or .xlsx files are allowed.");
            return "redirect:/index";
        }

        try {
            // Save the file to the uploads directory
            Path path = Paths.get(UPLOAD_DIR + file.getOriginalFilename());
            Files.createDirectories(path.getParent());
            Files.write(path, file.getBytes());

            // Save file metadata to the database
            FileMetadata metadata = new FileMetadata(file.getOriginalFilename(), file.getContentType(), file.getSize());
            fileMetadataRepository.save(metadata);

            // Parse the file to preview
            List<List<String>> filePreview = fileParserService.parseFile(file);
            List<String> headerLine1 = filePreview.get(0);
            List<List<String>> dataRows = filePreview.subList(1, filePreview.size());

            // Clean the data by removing rows with missing values
            List<List<String>> cleanedData = dataAnalysisService.removeRowsWithMissingValues(dataRows);
            cleanedData.sort(Comparator.comparing(row -> row.get(0))); // Sort data by date or other relevant column

            // Extract price data for analysis
            List<Double> prices = timeSeriesService.getPriceData(cleanedData);
            List<Double> cleanedPrices = dataAnalysisService.removeOutliers(prices); // Remove outliers
            List<Double> normalizedPrices = dataAnalysisService.normalizeData(cleanedPrices); // Normalize prices

            // Prepare last 10 rows for preview
            List<List<String>> lastTenRows = cleanedData.size() > 10 ? cleanedData.subList(cleanedData.size() - 10, cleanedData.size()) : cleanedData;
            List<List<String>> finalData = new ArrayList<>();
            finalData.add(headerLine1); // Add the header
            finalData.addAll(lastTenRows); // Add last 10 rows

            // Add file preview to redirect attributes for displaying on the UI
            redirectAttributes.addFlashAttribute("filePreview", finalData);

            // Perform descriptive statistics on the cleaned data
            Map<String, Object> priceStats = statisticsService.calculateDescriptiveStats(cleanedData);
            redirectAttributes.addFlashAttribute("priceStats", priceStats);

            // Perform time series analysis (e.g., trend, seasonality)
            Map<String, List<?>> timeSeries = timeSeriesService.timeSeriesAnalysis(cleanedData);
            redirectAttributes.addFlashAttribute("timeSeries", timeSeries);

            // Perform trend-seasonality-residuals analysis
            Map<String, List<?>> trendSeasonalityResiduals = statisticsService.calculateTrendSeasonalityResiduals(cleanedData);
            redirectAttributes.addFlashAttribute("trend", trendSeasonalityResiduals.get("trend"));
            redirectAttributes.addFlashAttribute("seasonal", trendSeasonalityResiduals.get("seasonal"));
            redirectAttributes.addFlashAttribute("residuals", trendSeasonalityResiduals.get("residuals"));

            // Calculate correlation between normalized prices and other data
            List<Double> otherData = timeSeriesService.getOtherData(cleanedData);
            double correlation = statisticsService.calculateCorrelation(normalizedPrices, otherData);
            redirectAttributes.addFlashAttribute("correlation", correlation);

            // Perform regression analysis
            Map<String, Double> regressionStats = statisticsService.performRegression(cleanedPrices, otherData);
            redirectAttributes.addFlashAttribute("regressionStats", regressionStats);

            // Predict future prices using time series model
            if (!cleanedData.isEmpty()) {
                List<Double> futurePrices = (List<Double>) timeSeries.get("prices");
                List<String> futureDates = (List<String>) timeSeries.get("dates");

                List<Map<String, Object>> futurePredictions = dataAnalysisService.trainAndPredict(futurePrices, futureDates);
                redirectAttributes.addFlashAttribute("futurePredictions", futurePredictions);
            }

            redirectAttributes.addFlashAttribute("message", "You successfully uploaded: " + file.getOriginalFilename());
        } catch (IOException e) {
            e.printStackTrace();
            redirectAttributes.addFlashAttribute("message", "Failed to upload file.");
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        return "redirect:/analyse";
    }

    private String getFileExtension(String fileName) {
        int index = fileName.lastIndexOf('.');
        return (index > 0) ? fileName.substring(index + 1) : "";
    }

    @GetMapping("/upload")
    public String showUploadForm() {
        return "index"; // Return the view where users can upload files
    }

    @GetMapping("/analyse")
    public String showDataPage() {
        return "analyse"; // Return the view where analysis results are displayed
    }
}
